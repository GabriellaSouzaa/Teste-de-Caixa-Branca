
# Sistema de Autenticação de Usuários

Este repositório contém um sistema básico de autenticação de usuários desenvolvido em Java, utilizando JDBC para conexão com um banco de dados MySQL.

O sistema valida login e senha dos usuários com base nos registros da tabela `usuarios` do banco de dados. Caso as credenciais sejam corretas, o sistema retorna o nome do usuário. Em caso de erros, mensagens são exibidas no console.
